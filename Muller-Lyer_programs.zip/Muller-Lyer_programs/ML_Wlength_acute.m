% This programm plots the simulated error and experimental error along with scale factor of the excitatory
% region of DOG with acute wing angle
XE= [5,10,15,20,25,30,35,40,45,50]';
%YE=[3.0035,3.7102,4.0636,4.4170,3.7102,1.9435,3.7102,0.8834,2.2968,-1.9435]';

%This part of the programm defines the Experimentally obtained eeror
YE=[3.0035,3.7102,4.0636,4.4170,3.7102,1.9435,3.7102,0.8834,2.2968,1.9435]';%For 18 degree
YE1=[1.5901,2.2963,1.5901,3.0035,4.0636,1.5901,1.9435,1.9435,1.2367,1.2367]';%For 36 degree
YE2=[0.53,1.5901,2.2968,3.3569,3.0035,2.2968,2.2968,1.5901,1.2367,0.8834]';%For 54 degree
YE3=[-0.1767,-0.1767,0.53,0.8834,1.9435,2.2968,2.2968,3.0035,3.3569,3.3569]';% For 72 degree
% Defining experimentally obtained error ends here.


%scatter(XE,YE2,'k *');
%hold on
%scatter(XE,YE1,'k o');
%figure();
% f=fit(XE,YE,'poly5');
% f1=fit(XE,YE1,'poly5');
% f2=fit(XE,YE2,'poly5');
% f3=fit(XE,YE3,'poly5');

% This part of the program generates  linearly inter polated data using the
% experimental data
f=fit(XE,YE,'linearinterp');  % For 18 degree
f1=fit(XE,YE1,'linearinterp');% For 36 degree
f2=fit(XE,YE2,'linearinterp');% For 54 degree 
f3=fit(XE,YE3,'linearinterp');% For 72 degree
% Linear interpolation ends here

% This part of the program draws the linearly interpolated experimental
% data
plot(f,'k');%,XE,YE)  % For 18 degree
hold on
plot(f1,'b');%,XE,YE) % For 36 degree
hold on
plot(f2,'g');%,XE,YE)% For 54 degree 
hold on
plot(f3,'m');%,XE,YE)% For 72 degree
axis([0 60 -4 5]);
xlabel('Wing lengths in pixels') 
ylabel('% of error in measuring the length') 
% Drawing of linearly interpolated data ends here.
figure();

% This part of the program generates the data for best fit curves of the experimental
% data using polynomial fitting 
fp=fit(XE,YE,'poly5'); % For 18 degree
fp1=fit(XE,YE1,'poly5');% For 36 degree
fp2=fit(XE,YE2,'poly5');% For 54 degree 
fp3=fit(XE,YE3,'poly5');% For 72 degree
% Generation of best fit data ends here

% This part of the program draws the linearly interpolated experimental
% data
plot(fp,'k--');%,XE,YE)% For 18 degree
hold on
plot(fp1,'k');%,XE,YE)% For 36 degree
hold on
plot(fp2,'k-.');%,XE,YE)% For 54 degree
hold on
plot(fp3,':k');%,XE,YE)% For 72 degree
axis([0 60 -4 5]);
% Drawing of linearly interpolated data ends here.
xlabel('Wing lengths in pixels') 
ylabel('% of error in measuring the length')
legend('Dashed curve corresponds to 18 degree.','Solid curve corresponds to 36 degree.','Dash-Dot curve corresponds to 54 gegree.','Dotted curve corresponds to 72 degree.');
figure();

%This part of the program defines the error generated through simulation

YS1=[3.0017,3.7094,4.0290,4.4166,3.7265,1.9025,1.1823,0.8570,0.6669,0.5326]';% For 18 degree
YS2=[1.5987,2.2624,2.3893,3.0053,4.0677,2.2851,1.9254,1.4128,1.3014,1.2345]';% For 36 degree
%YS3=[0.5675,1.6007,2.2914,3.3792,3.0007,3.2086,3.1348,1.5909,1.2279,-0.5311]';% For 54 degree
YS3=[0.5675,1.6007,2.2914,3.3792,3.0007,2.9086,2.8048,1.5909,1.2279,-0.5311]';
YS4=[-1.7486,-1.8569,0.5415,0.8422,1.9329,2.3042,2.9871,3.0386,3.2976,3.5501]';% For 72 degree
% Generation of simulated data ends here

% This part of the programme plots the error obtaind experimentally
% (Linearly interpolated) along with the simulated curve for 18 and 36 degree.
fse=fit(XE,YE,'poly5');%linearinterp    % For 18 degree
fs1=fit(XE,YS1,'poly5');
plot(fse,'k--');
hold on
plot(fs1,'k');
xlabel('Wing length in pixel') 
ylabel('% of error in measuring the length')
legend('Dashed curve represents the best fitted experimental data.', ' Solid curve represents the  simulated data.');
axis([0 60 -4 5]);
figure();
fse1=fit(XE,YE1,'poly5'); %linearinterp % For 36 degree
fs2=fit(XE,YS2,'poly5');
plot(fse1,'k');
hold on
plot(fs2,'k--');
xlabel('Wing length in pixel') 
ylabel('% of error in measuring the length')
legend('Solid curve represents the best fitted experimental data.', ' Dashed curve represents the  simulated data.');
axis([0 60 -4 5]);
figure();
fse2=fit(XE,YE2,'poly5');% For 54 degree
plot(fse2,'k-.');
hold on
fs2=fit(XE,YS3,'poly5');
plot(fs2,'k');
xlabel('Wing length in pixel') 
ylabel('% of error in measuring the length')
legend('Dash-Dot curve represents the best fitted experimental data.', ' Solid curve represents the  simulated data.');
axis([0 60 -4 5]);
figure();
fse3=fit(XE,YE3,'poly5');% For 72 degree
plot(fse3,':k');
hold on
fs3=fit(XE,YS4,'poly5');
plot(fs3,'k');
axis([0 60 -1 6]);%10
xlabel('Wing length in pixel') 
ylabel('% of error in measuring the length')
legend('Dotted curve represents the best fitted experimental data.', ' Solid curve represents the  simulated data.');
axis([0 60 -4 5]);

figure();
%Plotting is compleated here



% fse=fit(XE,YE1,'linearinterp');
% fs2=fit(XE,YS2,'poly5');
% plot(fse,'k');
% hold on
% plot(fs2,'k--');
% axis([0 60 -4 10]);

%This part of the program plots the variation scale factors of DOG ( sigma1
%and sigma2) with wing angle for different angle

% This part is for s1
s1=[0.523,0.559,0.553,0.546,0.546,0.561,0.563,0.565,0.566,0.567];
plot(XE,s1,'k--');
hold on
s3=[0.6112,0.8,0.7,0.98,1.0,1.08,1.08,1.09,1.09,1.09];
plot(XE,s3,'r--');
hold on
s5=[0.846,1.6025,1.8516,1.9941,2.16,2.273,2.291,2.45,2.76,2.85239];
plot(XE,s5,'g--');
hold on
s7=[0.926,0.915,1.222,1.75,2.42,2.449,2.35,2.343,2.3634,2.62];
plot(XE,s7,'b--');
% Plot of s1 degree ends here
figure();
% This part is for s2
s2=[0.6716,0.7813,0.784,0.787,0.799,0.81,0.82,0.823,0.825,0.826];
plot(XE,s2,'k');
hold on
s4=[0.869,0.923,3.25,3.656,3.863,3.864,3.9,3.91,3.92,3.926];
plot(XE,s4,'r');
hold on
s6=[1.2,4.3,4.91,5.0,5.6875,5.558,5.61,5.62,5.68,6.0];
plot(XE,s6,'g');
hold on
s8=[1.75,2.20,3.00,3.6,3.692,3.711,3.854,3.862,4.0,4.66];
plot(XE,s8,'b');
axis([0 60 0 8]);
%plot of s2 ends here


