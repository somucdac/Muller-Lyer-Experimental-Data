
% This programm plots the simulated error and experimental error along with scale factor of the excitatory
% region of DOG with obtused wing angle

XE= [5,10,15,20,25,30,35,40,45,50]'; % length of the wing
YE=[0.1767,0.8834,0.8834,1.5901,-0.8834,-0.5300,-1.2367,-0.5300,-0.5300,-1.2367]';% Expt error (%) For 90 degree
plot(XE,YE,'k');
hold on
YE1=[0.5300,0.8834,1.2367,1.5901,2.2963,1.2367,0.8834,0.1767,0.1767,-0.5300]';%for 108 degree
plot(XE,YE1,'r');
hold on
YE2=[1.5901,2.2968,2.6502,2.2968,3.0035,2.2968,2.2968,2.6502,1.5901,1.2367]';% For 126 degree
plot(XE,YE2,'g');
hold on
%YE3=[2.6502,3.3569,2.6502,3.0035,3.0035,1.5901,1.5901,1.2367,1.2367,1.2367]';%,For 144 degree
YE3=[2.2968,2.6502,3.0035,3.7102,3.3569,3.0035,2.6502,2.2968,2.2968,1.5901]';%,For 144 degree
plot(XE,YE3,'b');
hold on
YE4=[3.0035,3.7102,4.7703,3.7102,3.3569,1.2367,0.8834,0.8834,0.1767,0.5300]';% For 162 degree
plot(XE,YE4,'m');
axis([0 50 -5 10]);
xlabel('Wing lengths in pixels') 
ylabel('% of error in measuring the length') 
figure();
fs=fit(XE,YE,'poly5');
plot(fs,'k');
hold on
fs1=fit(XE,YE1,'poly5');
plot(fs1,'k--'); %r
hold on
fs2=fit(XE,YE2,'poly5');
plot(fs2,'k-.'); %g
hold on
fs3=fit(XE,YE3,'poly5');
plot(fs3,'k:'); %b
hold on
fs4=fit(XE,YE4,'poly5');
plot(fs4,'k.');
axis([0 50 -5 20]);
xlabel('Wing lengths in pixels') 
ylabel('% of error in measuring the length') 
axis([5 50 -5 20]);
legend('Thin solid curve represents 90 degree','dashed curve represents 108 degree', 'Dash-Dot curve represents 126 degree', 'Dotted curve represents 144 degree','Thick solid curve represents 162 degree.');  
figure();
YS=[0.1793,0.8844,0.8571,1.5855,-0.8678,-0.5379,-1.2361,-0.6390,-0.5358,-0.4320];
YS1=[0.5306,0.8977,1.2446,1.5963,2.2975,1.2327,0.8840,0.6199,0.3563,0.1654];
YS2=[1.5962,2.3115,2.6535,2.3536,3.1110,2.3198,2.3198,2.6209,1.5243,1.2632];
YS3=[2.2972,2.6566,3.055,3.7122,3.3588,3.0348,2.6473,2.0798,1.9564,1.9385];
YS4=[3.0089,3.7141,4.7714,3.7298,3.5725,1.2353,0.8901,0.8747,0.1754,0.1623];
plot(XE,YE,'k');% Form 90 degree
hold on
plot(XE,YS,'k--');% 90 degree ends here
hold on
plot(XE,YE1,'r');%for 108 degree 
hold on
plot(XE,YS1,'r--');%108 degree ends here
hold on
plot(XE,YE2,'g');%for 126 degree
hold on
plot(XE,YS2,'g--');%126 degeree ends here
hold on
plot(XE,YE3,'b');%for 144 degree
hold on
plot(XE,YS3,'b--');%144 degree ends here
hold on
plot(XE,YE4,'m');%for 144 degree
hold on
plot(XE,YS4,'m--');%144 degree ends here
axis([0 50 -5 10]);
figure();
s1=[1.01,1.91,1.90,2.1,2.1,2.1,2.2,2.25,2.26,2.27];%for 90 degree
s2=[1.9243,2.8476,2.851,3.718,3.73,3.34,3.342,3.35,3.35,3.35];%for 90 degree
s3=[1.006331,1.407,1.407,1.401,1.84,2.21,2.8,3.1,3.6,3.6];%For 108 degree
s4=[1.59,3.101,3.656,4.101,4.1,4.173,4.1905,4.2,4.21,4.21];%For 108 degree
s5= [1.1185,1.142,1.13,0.682,2.2,2.158,2.158,2.19,2.18,2.179];%for 126 degree
s6= [1.574,1.4742,1.44,1.41,5.44,5.442,5.442,5.445,5.438,5.4343];%for 126 degree
s7=[1.121,1.129,1.3,1.323,1.721,2.8,3.12,3.82,5.12,5.12];%For 144 degree
s8=[1.5846,1.5904,2.505,2.78,2.9,4.25,4.56,4.84,7.25,7.249];%For 144 degree
s9=[1.5,1.69,2.3,3.0,3.2165,3.452,3.458,3.47,3.489,3.5];
s10=[1.55,2.5855,2.8783,3.2229,3.85,3.8673,4.12,4.351,5.351,5.355];
plot(XE,s1,'k');
hold on
plot(XE,s2,'k--');
axis([0 50 -5 10]);
xlabel('Wing lengths in pixels') 
ylabel('Variation of standard deviations')
legend('Solid curve corresponds to the s.d of the center', 'Dashed curve represents the s.d of the surround');
figure();
plot(XE,s3,'k');
hold on
plot(XE,s4,'k--');
axis([0 50 -5 10]);
xlabel('Wing lengths in pixels') 
ylabel('Variation of standard deviations')
legend('Solid curve corresponds to the s.d of the center', 'Dashed curve represents the s.d of the surround');
figure();
plot(XE,s5,'k');
hold on
plot(XE,s6,'k--');
axis([0 50 -5 10]);
xlabel('Wing lengths in pixels') 
ylabel('Variation of standard deviations')
legend('Solid curve corresponds to the s.d of the center', 'Dashed curve represents the s.d of the surround');
figure();
plot(XE,s7,'k');
hold on
plot(XE,s8,'k--');
axis([0 50 -5 10]);
xlabel('Wing lengths in pixels') 
ylabel('Variation of standard deviations')
legend('Solid curve corresponds to the s.d of the center', 'Dashed curve represents the s.d of the surround');
figure();
plot(XE,s9,'k');
hold on
plot(XE,s10,'k--');
axis([0 50 -5 10]);
xlabel('Wing lengths in pixels') 
ylabel('Variation of standard deviations')
legend('Solid curve corresponds to the s.d of the center', 'Dashed curve represents the s.d of the surround');