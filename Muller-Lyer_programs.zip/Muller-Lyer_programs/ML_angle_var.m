% This programme generates the Muller Lyer figure of varying angle convolve
% it with Gaussian filter and Calculates the path length.
clc;
clear;
%axis([0 250 0 50]);
% This part of the programme draws the shaft.
x1 = 50;
y1 = 10;%10 
x2 = 226;
y2 = 10; %10
im=zeros(300);
xl1=[x1,x2];
xl2=[y1,y2]; 
%plot([x1 x2],[y1 y2],'color','k');
hold on
%Shaft Drawing is completed.

%This part of the programme Draws the inward arrow in the left end
  th1=30;%15.0;%This parameter changes the wing angle %135.1
  th=th1;
  r=56; 
  r1=r*cosd(th);
  r2=r*sind(th);
  x3=round(50+r1);
  y3=round(10+r2);
  xa1=[x1,x3];
  xa2=[y1,y3];
%   plot([x1 x3], [y1 y3],'color','k');
%   hold on
  th=-th1;
   %r=30; 
   r1=(r*cosd(th));
   r2=(r*sind(th));
   x4=round(50+r1);
   y4=round(10+r2);
   xa1=[x1,x4];
   xa2=[y1,y4];
%    plot([x1 x4], [y1 y4],'color','k');
%    hold on
% % Drawing Inward arrow in the left side is completed here.
% % This part of the programme Draws the inward arrow in the right end

th=th1;

  r1=(r*cosd(th));
  r2=(r*sind(th));
  x5=round(226-r1);
  y5=round(10+r2);
 
  xa1=[x2,x5];
  xa2=[y2,y5];
%   plot([x2 x5], [y2 y5],'color','k');
%   hold on
 th=-th;
 r1=(r*cosd(th));
 r2=(r*sind(th));
 x6=round(226-r1);
 y6=round(10+r2);
 xa1=[x2,x6];
 xa2=[y2,y6];
%  plot([x2 x6], [y2 y6],'color','k')
%  axis([0 340 -100 100]);
%  hold off
%  figure();
% Drawing of the inward arrow in the right end ends here.170; 




% This part of the program generates the bmp image for inword wing
im(y1,x1:x2) = 0;
y1=y1+140;
%for out word wing
%th=80;
sc=50;
for j = 0:0.1:(x2-x1)   
    im(y1,x1 + round(j)) = 1;%y1 The minus sign in (y1-round() is to handle the Matlab protocol that y coodinat decreases up side
end
 
for j = 0:1:sc
    
   
   im(y1-round(j*sind(th1)),x1+round(j*cosd(th1))) = 1;
  
end
  

 for j = 0:0.1:sc
     im(y1-round(j*sind(-th1)),x1+round(j*cosd(-th1))) = 1;
     
 end

th1=180-th1; 

 
 for j = 0:0.1:sc 
    im(y1+round(-j*sind(th1)),x2-round(-j*cosd(th1))) = 1;%y1 The minus sign in (y1-round() is to handle the Matlab protocol that y coodinat decreases up side
 end

 
 for j = 0:0.1:sc
     
    im(y1-round(-j*sind(th1)),x2-round(-j*cosd(th1))) = 1;%y1 The minus sign in (y1-round() is to handle the Matlab protocol that y coodinat decreases up side
 end
imwrite(im,'ML.bmp');
imshow(im);
figure();


% The generation of bit map for Muller_Lyer stimulus ends here.




% This Part of the programme generates the Gaussian Kernel
% This part of the programme sets the parameter for creating the filter
xmin = -10;
xmax =  10;
ymin = -10;
ymax =  10;
spacing = 0.13;
xvals = xmin:spacing:xmax+spacing/2;
yvals = ymin:spacing:ymax+spacing/2;
[x,y] = meshgrid(xvals, yvals);

% Parameter setting for Filter kernel starts here
k1 =1; 
k2 =1;

c1 = 1.608;    
c2 = 2.59; 

a1 = k1/(sqrt(2*pi*c1*c1));
a2 = k2/(sqrt(2*pi*c2*c2));


% Defining the kernel

count = 1;
  %loop filling in the values of the kernel of 'g'.
    for i= 1:1:size(x,1);
         for j=1:1:size(x,2);
              x1(count)= x(i,j);
              y1(count)= y(i,j);    
 
 f1(i,j)=(a1*exp(-(x1(count).*x1(count)+y1(count).*y1(count))./(2*c1*c1)))-(a2*exp(-(x1(count).*x1(count)+y1(count).*y1(count))./(2*c2*c2)));%
 
   count = count + 1;
        end
    end    
  f=f1;
   surfc(f);
   figure();
   
   
 % convolution of the input image with Gaussian kernel starts here.

 P = conv2(double(im),double(f),'same');     
   
    P2=max(P(:));
    
     P3=P.*255.0/P2;
    
    %surfc(P3);
    contour(P3,'k');%,'ShowText','on'); 
     figure();
     surfc(P3);
    
 % This part of the programme finds the coodinates of the Max values
  
 P_temp1=zeros(size(P3,1),size(P3,2)/2);
 P_temp2=zeros(size(P3,1),size(P3,2)/2);
for a=1:size(P3,1); 
 for x=4:(size(P3,2)/2);
      P_temp1(a,x)=P3(a,x);
 end;
 for x=(1:(size(P3,2)/2));
      P_temp2(a,x)=P3(a,x+(size(P3,2)/2));
 end;
end;

  max(P_temp1(:));
  max(P_temp2(:));



 
[max1,ind1] = max(P_temp1(:));


 
 
[I_row1,I_col1] = ind2sub(size(P_temp1),ind1);  
  

 [max2,ind2] = max(P_temp2(:));
 
 
 [I_row2,I_col2] = ind2sub(size(P_temp2),ind2);
 I_col2_new=I_col2+size(P3,2)/2;  
    
  XI=I_col1;
  XF=I_col2_new;
  YI=I_row1;
  LO=226-50;       
  if XI<XF
  LI=XF-XI;
  else 
  LI=XI-XF;  
  end     
  Pr=100/176;
  E=(LI-LO)*Pr;     
  figure();
  surf(P3) % Copied upto this part
  
  h = gcf; %current figure handle
  axesObjs = get(h,'Children');  %axes handles
  dataObjs = get(axesObjs,'Children'); %handles to low-level graphics objects in axes
  %get data 
  XX = dataObjs.XData ;
  YY = dataObjs.YData ;
  ZZ = dataObjs.ZData ;

 

%

% Cropping Gaussian peaks from surf plot For angles greater than 90 degrees% 
      for XX=1:1:31      
          for YY=1:1:31
            Xn=XI-15;
            Yn=YI-15;
            cc(XX,YY)=ZZ((YY+Yn),(XX+Xn));%ZZ((YY+145),(XX+48))
            cc1=(cc/255);
        end
      end
% For angles greater than 90 degrees   
    
 surf(cc1);
 xm = max(cc(:));
 xcm =cc(1,:);
 xm1=std2(cc1)
 LI1=LI/xm1
 E1=(LI1-LO)*Pr; %This part calculates the error.     
%The program ends here %



 






  
  
  
  